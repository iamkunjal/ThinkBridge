﻿using System;
using Microsoft.AspNetCore.Mvc;
using ShopBridge.Data;

namespace ShopBridge.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BaseApiController : ControllerBase
    {
        
    }
}
