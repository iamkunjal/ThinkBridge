﻿using System;
namespace ShopBridge.Controllers
{
    public class AcountController : BaseApiController
    {
        public AcountController()
        {
        }
    }
}
